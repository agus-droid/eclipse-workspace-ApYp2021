package maquinasDeCafe;

public class VasoDeCafe {
	private boolean lleno;

	public VasoDeCafe(boolean lleno) {
		this.lleno = lleno;
	}

	public boolean estaLleno() {
		return this.lleno;
	}
}
