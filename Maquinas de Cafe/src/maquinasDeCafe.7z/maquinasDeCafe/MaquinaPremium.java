package maquinasDeCafe;

public class MaquinaPremium extends MaquinaDeCafe {
	
}
